<?php  	

	
	
	$a=1;
	$b=4;
	$c=2;
	
	if($a>$b || $a==$b)
	{
	echo "ok";
	}
	elseif($c==2)
	{
	echo "ok";
	}
	else
	{
	echo "not ok";
	}
	
	
		
		
		

	for($a=1,$b=3;$a<3;$b=$b+1,$a=$a+2,$c++){
		if($r < 4){
			$a = 3;
		}
aaa
	}
	
	echo "abc";
	
	echo "aaa"."bbb";
	
	echo "aaa".$abc+$bcd;


?>


